echo -e "Write a shell script which receives 2 file names as argument and it should check whether 2 files contents are same or not. 
If they are then 2nd file should be deleted."


file1=$1
file2=$2
cmp $file1 $file2
if [ `echo $?` -eq 0 ]
then
echo "$file1 and $file2 are same"
echo "now deleting file2........."
rm $file2
echo "deletion successfully"
else
echo "2 files are not at all same"
fi