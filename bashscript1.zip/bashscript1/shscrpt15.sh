echo "Write a shell script to enter color from the user and display user's favorite color."

echo "Enter a color:"
read color
case $color in
[rR][eE][dD])echo "Your choice is RED color.";;
[bB][lL][uU][eE])echo "Your choice is BLUE color.";;
[pP][iI][nN][kK])echo "Your choice is PINK color";;
*)
echo "Please enter valid color."
esac