 echo "Write a shell script to print weekday name corresponding to week number."

echo "Enter weekday number:"
read m
case $m in
1) echo Sun;;
2) echo Mon;;
3) echo Tue;;
4) echo Wed;;
5) echo Thur;;
6) echo Fri;;
7) echo Sat;;
*) echo "Please enter valid week number."
esac