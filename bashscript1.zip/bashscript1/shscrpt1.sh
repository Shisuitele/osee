echo -e " 1] Write a shell program to execute the following:
\n i] Display calendar of current year.
\n ii] Display today's date.
\n iii] Display list of all users currently logged in.
\n iv] Display message Hello World.
\n v] Perform some calculation.\n "


echo "Calendar of current month:"
cal
echo "Today's date:"
date
echo "Users currently logged in:"
who
echo "Hello World"
echo "Calculation of:"
bc