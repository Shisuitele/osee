echo -e "The basic salary of an employee is entered if the basic salary is less than or equal to 1500,
hra=10%, da=90% of basic salary will be given to employee of the basic salary is greater than 1500 then hra=500 and da=90% will be given. 
Write a shell script to find gross salary"


echo "Enter basic salary:"
read b
if [ $b -le 1500 ]
then
hra=`echo 0.10\*$b|bc`
da=`echo 0.90\*$b|bc`
gs=`echo $b+$hra+$da|bc`
echo "Gross Salary is $gs"
else
hra=500
da=`echo 0.98\*$b|bc`
gs=`echo $b+$hra+$da|bc`
echo "Gross Salary is $gs"
fi