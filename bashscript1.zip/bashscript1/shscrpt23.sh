echo -e "Write a shell script to read file name from user and check whether the file name exists. If it is then read pattern from the user and check whether that pattern exists or not. 
If it is display lines containing this pattern otherwise display appropriate message."


echo "Enter file name :"
read f
if [ -f$f ]
then
echo "$f file exists."
echo "Enter pattern :"
read pat
x=`grep -c $pat $f`
if [ $x -gt 0 ]
then
echo "Pattern found."
echo "Line containing $pat in $f are :"
grep "$pat" $f
else
echo "Pattern not found."
fi
else
echo "File does not exists."
fi