echo "Write a shell script to check whether the year entered is leap or not."


echo "Enter a year :"
read year
if [ `expr $year % 4` -eq 0 ]
then
echo "The entered year is leap year."
else
echo "The entered year is not a leap year."
fi