echo "Write a shell script to read 2 strings and check whether the strings are identical. Print appropriate
message."

echo "Enter line 1: "
read m
echo "Enter line 2: "
read n
if [ $m == $n ]
then
echo "identical"
else
echo "different"
fi