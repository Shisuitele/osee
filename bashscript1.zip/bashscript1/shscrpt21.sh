echo  -e " Write a shell script to read a file name from the user and check whether it exists or not. 
If exists then check it is non-empty or not, if non-empty display the contents 
of the file and print appropriate message."


echo "Enter file name :"
read f
if [ -f$f ]
then
echo "$f file exists."
x=`ls $f|wc -l`
if [ $x -gt 0 ]
then
echo "$f file is not empty."
echo "The content of $f is"
cat $f
else
echo "$f is empty."
fi
else
echo "$f does nor exists."
fi