echo -e "Write a shell script to initialize values in 2 variables and perform addition, subtraction,
multiplication, division, modulus and print the appropriate result(user input).
\n"
echo "enter variable 1"
read var1
 echo "enter variable 2"
read var2
echo "Sum:`expr $var1 + $var2`"
echo "Difference:`expr $var1 - $var2`"
echo "Product:`expr $var1 \* $var2`"
echo "Division:`expr $var1 / $var2`"
echo "Modulus:`expr $var1 % $var2`"