echo " Write a shell script to accept a number from the user and check whether it is even or odd."

echo "Enter a number:"
read a
if [ `expr $a % 2` -eq 0 ]
then
echo "Even number."
else
echo "Odd number."
fi