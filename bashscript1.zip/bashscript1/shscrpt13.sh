echo "Write a shell script to perform one of the following between 2 numbers : +, -, *, /, %, exit."

echo "Enter 1 for addition"
echo "Enter 2 for subtraction"
echo "Enter 3 for multiplication"
echo "Enter 4 for division"
echo "Enter 5 for modulus"
read ch
case $ch in
1)echo "Enter 2 numbers :"
read x
read y
add=`expr $x + $y`
echo "Addition :$add";;
2)echo "Enter 2 numbers :"
read x
read y
sub=`expr $x - $y`
echo "Subtraction :$sub";;
3)echo "Enter 2 numbers :"
read x
read y
mul=`expr $x \* $y`
echo "Multiplication :$mul";;
4)echo "Enter 2 numbers :"
read x
read y
div=`expr $x / $y`
echo "Division :$div";;
5)echo "Enter 2 numbers :"
read x
read y
mod=`expr $x % $y`
echo "Modulus :$mod";;
6)exit;;
*)echo "Please enter valid choice"
esac