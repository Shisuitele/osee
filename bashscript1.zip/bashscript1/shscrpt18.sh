echo -e "Write a shell script to read file name from user and find the 
type of the file whether it is .txt or .sh type file."

echo "Enter a file name:"
read f
case $f in
*.txt)
echo "This is txt type file.";;
*.sh)
echo "This is sh type file.";;
*)
echo "This is some other type.";;
esac