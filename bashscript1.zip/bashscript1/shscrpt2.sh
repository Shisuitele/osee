echo -e "2] Write a shell program to execute the following commands:
\n i] Display present working directory
\n ii] Display today's date and time in 2 different lines.
\n iii] Display your terminal address.
\n iv] Display login name of user currently logged in.
\n v] Display all processes of the users.
\n vi] Display all files and directories in current working directory.\n"

echo "Present working directory is "
pwd
echo "Today's date is"
date +%D
echo "Today's time is "
date +%r
echo "Terminal address:"
tty
echo "Name of user currently logged in:"
who am i
echo "Process of the user"
ps
echo "Files and Directories in current working directory"
ls -l