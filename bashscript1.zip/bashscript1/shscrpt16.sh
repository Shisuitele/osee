echo -e " Write a shell script to read word from the user and check whether 
it is starting with the lowercase vowel letter or uppercase or ends with a 
digit or starts with digit or it is 3 letter word."

echo "Enter word :"
read word
case $word in
[aeiou]*)
echo "Your entered vowel is in lowercase.";;
[AEIOU]*)
echo "Your entered vowel is in UPPERCASE.";;
[0-9]*)
echo "Your entered word starting with a digit.";;
*[0-9])
echo "Your entered word ending with a digit.";;
???)
echo "You entered a 3 letter word";;
esac