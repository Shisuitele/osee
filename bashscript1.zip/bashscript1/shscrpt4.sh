echo -e "Write a shell script to read input from the user and check whether it is greater than 10 or not."

echo "Enter a number:"
read a
if [ $a -gt 10 ]
then
echo "$a is greater than 10"
else
echo "$a is less than 10"
fi