echo -e "Write a shell script to read a filename and check if it exists readable or writable. \
If yes allow the user to append the content in the file and print appropriate message."

echo "Enter file name :"
read f
if [ -f$f ]
then
echo "$f file exists."
echo "The contents of $f :"
cat $f
if [ -w $f ]
then
echo "$f has write permission."
echo "Now you can append."
cat>>$f
else
echo "$f doesn't have permission."
fi
else
echo "$f doesn't exists."
fi