echo -e "Write a shell script to read number from the user and check whether it is divisible by 3 and 7 or only by 3 or only by 7 or not by both"

echo "Enter a number :"
read a
if [ `expr $a % 3` -eq 0 ]
then
echo "Divisible by 3."
else
echo "Not divisible by 3."
fi
if [ `expr $a % 7` -eq 0 ]
then
echo "Divisible by 7."
else
echo "Not Divisible by 7."
fi