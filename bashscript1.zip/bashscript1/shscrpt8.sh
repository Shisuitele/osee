echo -e "Write a shell script to read marks of 5 subjects and find the total,
percentage and grade of student."


echo "Enter 5 subject marks :"
read m1
read m2
read m3
read m4
read m5
tot=`expr $m1+$m2+$m3+$m4+$m5|bc`
per=`expr $tot/5|bc`
echo "Total is $tot"
echo "Percentage is $per"
if [ $per -lt 35 ]
then
echo "Fail."
elif [ $per -ge 35 -a $per -lt 45 ]
then
echo "Third class."
elif [ $per -ge 45 -a $per -lt 60 ]
then
echo "Second class."
else
echo "First Class."
fi