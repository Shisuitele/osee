echo -e "Write a shell script to read a string from command line argument and 
check whether its length is greater than or equal to 12. 
Print appropriate message."

str=$1
len=${#str}
if [ $len -ge 12 ]
then
echo "$1 string length is greater than 12."
else
echo "$1 string length is less than 12."
fi