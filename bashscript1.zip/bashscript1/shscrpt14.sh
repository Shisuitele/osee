echo -e "Write a shell script to read character from the user and check the type 
of character i.e. upper, lowercase, digit or a special symbol otherwise display 
appropriate message as 'You have entered more
than 1 character'."

echo "Enter a character"
read ch
case $ch in
[A-Z])
echo "Uppercase";;
[a-z])
echo "Lowercase";;
[0-9])
echo "Numbers";;
?)
echo "Special character";;
*)
echo "You have entered more than 1 character"
esac