echo "Write a shell script to read a choice between A-E and do the following:"

echo "Enter your choice"
echo "a) Enter a to display today's date."
echo "b) Enter b to display the calendar of current year. "
echo "c) Enter c to list all users currently logged in."
echo "d) Enter d to perform some calculations."
echo "e) Enter e to exit."
read ch
case $ch in
a)echo "Today's date"
date;;
b)echo "Current year calendar"
cal;;
c)echo "All users currently logged in"
who;;
d)echo "Calculation of"
bc;;
e)exit;;
esac