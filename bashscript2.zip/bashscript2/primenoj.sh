flag=0
echo "Enter number: "
read no
echo "Series of prime numbers upto $no: "
for((i=2;i<=no;i++))
do
for((j=2;j<i;j++))
do
if [ `expr $i % $j ` -eq 0 ]
then
flag=1
fi
done
if [ $flag -eq 0 ]
then
echo $i
fi
flag=0
done