echo "Enter any number :"
read num
fact=1
if [ $num -lt 0 ]
then
echo "Please enter positive number."
else
for(( i=1;i<=num;i++ ))
do
for(( j=1;j<=$i;j++ ))
do
fact=$[ $fact * $j ]
done
echo "$i!= $fact"
fact=1
done
fi