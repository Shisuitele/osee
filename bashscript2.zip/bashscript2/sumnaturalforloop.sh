echo "Enter a number :"
read n
i=1
sumsq=0
for ((i=1;i<=n;i++))
do
sumsq=$[ $sumsq + $i * $i ]
done
echo "The sum of square $n natural numbers : $sumsq"