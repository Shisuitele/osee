echo "Enter a number :"
read n
i=1
sum=0
until [ $i -gt $n ]
do
sum=$[ $sum+$i]
i=$[ $i+1 ]
done
echo "The sum of $n natural numbers : $sum"