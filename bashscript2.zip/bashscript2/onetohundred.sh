i=1
j=3
while [ $i -le 100 ]
do
echo $i
echo $j
i=$[ $i + 1 ]
j=$[ $j + 1 ]
done